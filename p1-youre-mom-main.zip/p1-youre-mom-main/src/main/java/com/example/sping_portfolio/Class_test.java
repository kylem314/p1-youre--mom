package com.example.sping_portfolio;

public class Class_test {
    String abc;
    int integer;

    public Class_test(int x, String y){
        integer = x;
        abc = y;

    }

    public int getInt(){
        return integer;
    }

    public String getString(){
        return abc;
    }
}
