package com.example.sping_portfolio;

public class Test {

    public static void main(String[] args){
        System.out.println("Hi");
    }
}
