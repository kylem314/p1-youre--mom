package com.example.sping_portfolio.controllers;

public class student_test {


    public static void main(String[] args) {
        student Kyle = new student();
        Kyle.average_grade(85, 96, 88);
    }
}
