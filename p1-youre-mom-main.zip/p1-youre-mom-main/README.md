## Del Norte Food Ordering Service
This project was created by Harry, Devam, Yajat, Flora, and Kyle. Our coding skills are rudimentary so any and all contributions will be welcomed. We will
judge each contribution. Our project is dedicated to helping our school, Del Norte High School, serve a smooth lunch experience. Its purpose is to allow students to order food from school online in order to reduce lunch line congestion. Our project uses Thymeleaf to fuse java and html elements. The project is publicly accessible on the web. To run the program, find main.java and run it. 

## Project Details (Pop Quiz)

m221_Penguins   | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1) | [Repo Contributors](https://github.com/yajatyadav/spring_portfolio/graphs/contributors) | ------ | ------ | ------ |
------ | ------ | ------ | ------ | ------ | ------ |
Name            | GitHub ID | Tasks | Scrum Board | Commits | Profile |
Kyle Myint | kylem314 | [Issues](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues?q=is%3Aissue+assignee%3Akylem314+) | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1?card_filter_query=assignee%3Akylem314) | [Issues](https://github.com/yajatyadav/spring_portfolio/issues/assigned/kylem314) -- [Commit Page](https://github.com/yajatyadav/spring_portfolio/commits?author=kylem314)| [Profile](https://github.com/kylem314) |
Devam Shrivastava | devamshri | [Issues](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues?q=is%3Aissue+assignee%3Adevamshri+) | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1?card_filter_query=assignee%3Adevamshri) | [Issues](https://github.com/yajatyadav/spring_portfolio/issues/assigned/devamshri) -- [Commit Page](https://github.com/yajatyadav/spring_portfolio/commits?author=devamshri) | [Profile](https://github.com/devamshri) |
Yajat Yadav | yajatyadav | [Issues](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues?q=is%3Aissue+assignee%3Ayajatyadav+) | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1?card_filter_query=assignee%3Ayajatyadav) | [Issues](https://github.com/yajatyadav/spring_portfolio/issues/assigned/yajatyadav) -- [Commit Page](https://github.com/yajatyadav/spring_portfolio/commits?author=yajatyadav) | [Profile](https://github.com/yajatyadav) | 
Flora Yuan | florayuan18 | [Issues](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues?q=is%3Aissue+assignee%3Aflorayuan18+) | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1?card_filter_query=assignee%3Aflorayuan18) | [Issues](https://github.com/yajatyadav/spring_portfolio/issues/assigned/florayuan18) -- [Commit Page](https://github.com/yajatyadav/spring_portfolio/commits?author=florayuan18) | [Profile](https://github.com/florayuan18) |
Harry Li | wiz124 | [Issues](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues?q=is%3Aissue+assignee%3Awiz124+) | [Scrum Board](https://github.com/yajatyadav/spring_portfolio/projects/1?card_filter_query=assignee%3Awiz124) | [Issues](https://github.com/yajatyadav/spring_portfolio/issues/assigned/wiz124) -- [Commit Page](https://github.com/yajatyadav/spring_portfolio/commits?author=wiz124) | [Profile](https://github.com/wiz124) |

## Final reflections & N@TM
Name             | Reflection link |
-------------    | -------------- | 
Kyle Myint | [Journal](https://docs.google.com/document/d/1-alkdDcceGG-o69JnpZia2obt1U8zChv7EBEt5bv1HE/edit?usp=sharing)|
Harry Li | [Journal](https://docs.google.com/document/d/1d0LasO441Eu_MtpE_ls5NWcNcYAKnS1D0UYqwhyFTQY/edit?usp=sharing)|
Devam Shrivastava | [Journal](https://docs.google.com/document/d/1ams_R9wWZBs3Y5xRbWLlmRN4uiJJmhoppbKn40Lhlgc/edit)|
Flora Yuan | [Journal](https://docs.google.com/document/d/1Lj7THBJb-QpJHe8qe5OsWpUpPsCb5o91J9JpXj4ZpFA/edit?usp=sharing)|
Yajat Yadav | [Journal](https://docs.google.com/document/d/1AGFgQEv73ZCuqD_dM7yOC3JB1mxQLiS7YM0RUrWyMo0/edit?usp=sharing)|

## Individual Final Part 1
Note: Scrum team comments are in each issue
Name             | Issue Link | Score | 
-------------    | -------------- | -------------- | 
Kyle Myint | [Issue](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues/53)| 5.75 / 6 | 
Harry Li | [Issue](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues/52)| 5.75 / 6 | 
Devam Shrivastava | [Issue](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues/49)| 5.5 / 6 | 
Flora Yuan | [Issue](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues/51)| 6 / 6 | 
Yajat Yadav | [Issue](https://github.com/devamshri/AllHailTheHolyScrumMaster/issues/50)| 5.75  / 6 | 

## N@tM Overview and Unit 8  10/20
Pair Share  |  Link
-------------    | -------------- | 
Yajat + Kyle | [Journal](https://docs.google.com/document/d/1Gc-86BvTlot4jyVBa4iQE2sjUcaYF_pDU6r2joCvn34/edit)
Flora + Devam + Harry | [Journal](https://docs.google.com/document/d/1ZbrZE_7m7otx_fzhOEZwBUQe3HiBdArVGhj036xgOZ4/edit?usp=sharing)

## Completed Issues 10/11-10/15
Issue Name             | Link | 
-------------    | -------------- | 
Issue name | [Issue](Link) |
Issue name | [Issue](Link) |
Issue name | [Issue](Link) |

## Modeling Checkpoint + Unit 7
### [Team Video](https://drive.google.com/file/d/1AGgbAhDmbF9_e15GR-5vDqg12HO3X3VS/view?usp=sharing)
Pair Share  |  Link
-------------    | -------------- | 
Yajat + Kyle | [Journal](https://docs.google.com/document/d/1Gc-86BvTlot4jyVBa4iQE2sjUcaYF_pDU6r2joCvn34/edit)
Flora + Devam + Harry | [Journal](https://docs.google.com/document/d/1j2SUFoxa5XTKc_XzALJ9SQDAT810OrmKYq4Sr1oO0-s/edit)

## Completed Issues 9/28 - 10/1
Issue Name             | Link | 
-------------    | -------------- | 
Issue name | [Issue](Link) |
Issue name | [Issue](Link) |
Issue name | [Issue](Link) |

## Unit 5 9/20-9/24
Name             | Link(s) | Score | 
-------------    | -------------- | -------------- | 
Kyle Myint | [Unit 5/Journal](https://docs.google.com/document/d/1CxsEdfdUGzKdkgkaZQxlAywKfanPuT3YYo9fy-y2DZU/edit?usp=sharing )| 5 / 5 | 
Harry Li | [Unit 5/Journal](https://docs.google.com/document/d/1Z8wut649FaYGxzvYylkW5rdL1nL5PG2Um-Ge4-RsKwo/edit)| 5 / 5 | 
Devam Shrivastava | [Unit 5/Journal](link)| 5 / 5 | 
Flora Yuan | [Unit 5/Journal](link)| 5 / 5 | 
Yajat Yadav | [Unit 5/Journal](link)| 5 / 5 | 

## Prototype Sprint End and Unit 4 9/13-9/17
[Team Document](https://docs.google.com/document/d/1J32KU4wGS6S89PuoYip7IkE_czWwMvMnCkQFUcXugF0/edit?usp=sharing)  ---  3 / 3

Name             | Link(s) | Score | 
-------------    | -------------- | -------------- | 
Kyle Myint | [Unit 4/Journal](https://docs.google.com/document/d/1CxsEdfdUGzKdkgkaZQxlAywKfanPuT3YYo9fy-y2DZU/edit) --- [Individual Technicals](https://docs.google.com/document/d/13NkJewmSA9jL_fS_LLqqos3HMYwHeZdugXIBA6_5AAg/edit?usp=sharing)| 7 / 7 | 
Harry Li | [Document](https://docs.google.com/document/d/1WWKJCEe1gDjJTDdgrik0eljGQHCxzATV62_QvdXGlVg/edit) | 5 / 5 | 
Devam Shrivastava | [Document](https://docs.google.com/document/d/1lUQ_udRR1pJ6LzKUM_6pWJmPsrRB-Fv0lp9Uvap1j5k/edit) | 5 / 5 |  
Flora Yuan | [Unit 4/Journal](https://docs.google.com/document/d/1chgaTpbgRCmXZyCK4A7hwueresrFDNeg2BjiKBzA3XM/edit?usp=sharing) | 5 / 5 |
Yajat Yadav | [Document](https://docs.google.com/document/d/1CxsEdfdUGzKdkgkaZQxlAywKfanPuT3YYo9fy-y2DZU/edit)| 5 / 5 | 

## Completed Issues 9/13-9/17
Issue Name             | Link | 
-------------    | -------------- | 
Thymeleaf for Menu Table and formatting | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/29)  |
Completed cost for menu items on menu page | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/36) |
Main page opener + picture display | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/39) |

## Prototype Check and Unit 3 9/6-9/10
Name             | Link(s) | Score | 
-------------    | -------------- | -------------- | 
Team PBL | [Document](https://docs.google.com/document/d/10An5E4cxTf8f4C0xxmIFeiW3VPrkqMKijo_gt5rHDZs/edit?usp=sharing)  | 5 / 5 |
Kyle Myint | [Document](https://docs.google.com/document/d/1CxsEdfdUGzKdkgkaZQxlAywKfanPuT3YYo9fy-y2DZU/edit) | 5 / 5 | 
Harry Li | [Document](https://docs.google.com/document/d/1ROEbYQ--ZeuYzCdiGoVsIqJUdvelKxbON_kpQ8kyJ5U/edit) | 5 / 5 | 
Devam Shrivastava | [Document](https://docs.google.com/document/d/1lUQ_udRR1pJ6LzKUM_6pWJmPsrRB-Fv0lp9Uvap1j5k/edit) | 5 / 5 |  
Flora Yuan | [Document](https://docs.google.com/document/d/1a9IQU3_uE1ipK_MvJwMlkhNlwpNBhdLAmtqbNlbwHQo/edit?usp=sharing) | 5 / 5 |
Yajat Yadav | [Document](https://docs.google.com/document/d/18WtqhehIF7iWMmhNLunfDmvwQxE_vz1laiWYDu0a9hs/edit?usp=sharing)| 5 / 5 | 

## Completed Issues 9/6-9/10
Issue Name             | Link | 
-------------    | -------------- | 
Update Readme | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/13)  |
Display Foods Available | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/15) | 
Layout Menu Page | [Issue](https://github.com/yajatyadav/spring_portfolio/issues/22) |


## Journal Links
Type             | Link(s) | Score | 
-------------    | -------------- | -------------- | 
Team PBL | [Document](https://docs.google.com/document/d/1X3RJ1Kt_juGq6w643cy4FqbSa7k2ZLt8QfRiYUg_PlQ/edit?usp=sharing)  | 3 / 3 |
Kyle Myint | [Document](https://docs.google.com/document/d/12ekGIsZJisLkJGaCuvXwtId8GWlxEanrqh6m2N8VmFo/edit?usp=sharing) | 7 / 7 | 
Harry Li | [Document](https://docs.google.com/document/d/1bCHUpg6SXnxEQVpmvC_yCZpuYMeff0Th3QgivQjexKw/edit#heading=h.usvbibhx2yce) | 7 / 7 | 
Devam Shrivastava | [Document](https://docs.google.com/document/d/1lUQ_udRR1pJ6LzKUM_6pWJmPsrRB-Fv0lp9Uvap1j5k/edit) | 7 / 7 | 
Flora Yuan | [Document](https://docs.google.com/document/d/1_QDCIAPbDgrp_2ae4xgov3GXOcW0bAwPcs4AZBxrn-0/edit?usp=sharing) | 7 / 7 |
Yajat Yadav | [Document](https://docs.google.com/document/d/1H7oCVp_NpeDNwuLqAO1a7uDIAogCc7RZWw9CcGLVmB4/edit?usp=sharing)| 7 / 7 | 

## TBD [Spring Portfolio Starter](https://nighthawkcodingsociety.com/projectsearch/details/Spring%20Portfolio%20Starter)
Runtime link: TBD https://jportfolio.nighthawkcodingsociety.com/



## Visual thoughts
#### * Starter code should be fun and practical
#### * Organize with Bootstrap menu 
#### * Add some color and fun through VANTA Visuals (birds, halo, solar, net)
#### * Show some practical and fun links (hrefs) like Twitter, Git, YouTube
#### * Show student project specific links (hrefs) per page
#### * Show student TPT ideas
#### * Show student About me page



## Getting started
#### * Clone project to IntelliJ
#### * Verify Project Structure to use a good Java JDK (adopt-openJ9-15) 
#### * Play or entry point is Main.java, look for play option in the tray.  This file enables Spring to load
#### * Java source (src/main/java) had Java files.  Find "controllers" path, these files enable HTTP route and HTML file relationship.  Note, html 
#### * HTML source (src/main/resources) had templates and supporting files.  Find index.html as this file is launched by default in Spring.  Other HTML files are loaded by building a "@Controller"



## IDE management
#### * A ".gitignore" can teach a Developer a lot about Java runtime.  A target directory is created when you press play button, byte code is generated and files are moved into this location.
#### * A "pom.xml" file can teach you a lot about Java dependencies.  This is similar to "requirements.txt" file in Python.  It manages packages and dependencies.

## Table of Collaborators 

NAME             | GITHUB Link |
-------------    | -------------- |
Kyle Myint | https://github.com/kylem314  |
Harry Li | https://github.com/wiz124 |  
Devam Shrivastava | https://github.com/devamshri |
Flora Yuan | https://github.com/florayuan18 |
Yajat Yadav | https://github.com/yajatyadav |

## Ideation

### Food ordering system for school cafeteria
#### Purpose of site
* Allow students to order food from a menu
* Create shorter wait times
#### Theme/Information:
* Login system with Student ID & password
* Dropdown menu selection + buttons to add items to cart
* Schedule for which food on which days
* Admin accounts able to change the menu
* Purchase history / Balance on an account page
* Some cool front page with 3D letter maybe
* Front page with recommendations
* Cart
* Checkout system
* Get an order # to pick up food
## PBL 1-2, and Unit 2
Type             | Link(s) | Score | 
-------------    | -------------- | -------------- | 
Team PBL | [Document](https://docs.google.com/document/d/1X3RJ1Kt_juGq6w643cy4FqbSa7k2ZLt8QfRiYUg_PlQ/edit?usp=sharing)  | 3 / 3 |
Kyle Myint | [Document](https://docs.google.com/document/d/12ekGIsZJisLkJGaCuvXwtId8GWlxEanrqh6m2N8VmFo/edit?usp=sharing) | 7 / 7 | 
Harry Li | [Document](https://docs.google.com/document/d/1bCHUpg6SXnxEQVpmvC_yCZpuYMeff0Th3QgivQjexKw/edit#heading=h.usvbibhx2yce) | 7 / 7 | 
Devam Shrivastava | [Document](https://docs.google.com/document/d/1lUQ_udRR1pJ6LzKUM_6pWJmPsrRB-Fv0lp9Uvap1j5k/edit) | 7 / 7 | 
Flora Yuan | [Document](https://docs.google.com/document/d/1_QDCIAPbDgrp_2ae4xgov3GXOcW0bAwPcs4AZBxrn-0/edit?usp=sharing) | 7 / 7 |
Yajat Yadav | [Document](https://docs.google.com/document/d/1H7oCVp_NpeDNwuLqAO1a7uDIAogCc7RZWw9CcGLVmB4/edit?usp=sharing)| 7 / 7 | 


